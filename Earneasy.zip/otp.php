<!DOCTYPE html><html lang="en"><head> <meta name="google" value="notranslate">	<meta charset="UTF-8">	<meta name="viewport" content="width=device-width, initial-scale=1.0"><meta content="Best Booster Maker Panel, Refer Booster" name="description">	<!-- Boxicons -->	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>	<!-- My CSS -->	<link rel="stylesheet" href="sstyle.css">
	<title>Lucifer</title>	<link href="https://i.ibb.co/8XM8whq/icon.png" rel="icon" type="image/x-icon"/>	<style>		 .input{ display: block; width: 90%; margin: 10px auto; text-align: center; color: black; font-family: 'Montserrat'; padding: 0; font-size: 15px; font-weight: 500; height: 40px; border: 1px solid #047aed; border-radius: 4px; background-color: #E1F5FE; outline: none; padding: 0 5px 0 5px; box-shadow: 0 5px 30px rgba(255, 255, 255, 0.1); } .submit{ height: 40px; width: 60%; border: 0; border-radius: 4px; margin: 0 auto; padding: 0 10px 0 10px; background: #047aed; font-family: 'Montserrat'; font-size: 14px; font-weight: 500; text-transform: capitalize; letter-spacing: 0; color: #FFFFFF; cursor: pointer; outline: none; box-shadow: 0 2px 5px 0 rgba(0, 0, 100,.2); }	 .alert { padding: 20px; background-color: #f44336; color: white; opacity: 1; transition: opacity 0.6s; margin-bottom: 15px;}
.alert.success {background-color: #04AA6D;}.alert.info {background-color: #2196F3;}.alert.warning {background-color: #ff9800;}
.closebtn { margin-left: 15px; color: white; font-weight: bold; float: right; font-size: 22px; line-height: 20px; cursor: pointer; transition: 0.3s;}
.closebtn:hover { color: black;}	</style></head><body><center><h3><br>Earneasy Refer Script</h3><br></center></body>
   <?php

$refer=$_REQUEST['refer'];
function httpCall($url, $data = "", $headers = array(), $method = "GET", $headerReturn = 0) {
  if(empty($headers)){
    $headers=["User-Agent: okhttp/3.12.1","Accept-Encoding: gzip, deflate"];
  }
  $ch = curl_init($url);
  curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
  curl_setopt($ch, CURLOPT_PROXY,"isp2.hydraproxy.com:9989");
  curl_setopt($ch, CURLOPT_PROXYUSERPWD, "rahu31332egps77393:tYJ7lmmQ5nOc54s7_country-India");
  curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL,0);
  curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_HEADER, $headerReturn);
  curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
  $output = curl_exec($ch);
  return $output;
}
$f = array("Vasu","Nirmal","Akshay","Chander","Rupinder","Akhil","Shanti","Ravi","Kunal","Chandrakant","Sulabha","Mahinder","Swapnil","Deepa","Sulabha","Neelima","Vijaya","Nikhil","Isha","Siddhi","Ajeet","Kshitija","Anila","Jitender","Sumeet","Preethi","Priti","Gayathri","Dhaval","Mukesh","Lalita","Rachana","Rakhi","Harshal","Shekhar","Rajiv","Balakrishna","Ajeet","Tara","Chander","Deepa","Prabhu","Rajendra","Jeetendra","Nandu","Aniket","Sumati","Prabhu","Vimal","Indira","Laxman","Agni","Kapil","Kailash","Puneet","Pratik","Pankaj","Ishore","Swati","Rupa","Hardeep","Prabhu","Khushi","Gurmeet","Nishant","Rishi","Naveen");
$fname = $f[mt_rand(0,60)];
 $l = array("sameer","suresh","chettiar","jatin","chauhan","agarwal","rahul","tanmay","tiwari","kunal","rasania","sunil","kumar","gaurav","arihant","jain","falguni","yashashree","arpi","arshish","gupta","tanmay","samtgr","kiyera","atul","abhay","chandra","shoibaakriti","aanchal","talreja","aatholiy","abhijeet","akkalwar","abhijeet","bajpai","abhijeetsh","abhirup","roy","abhishek","sumit","kapil","rani","ramu","souvik","yogesh","umesh","sahadat","ankit","prasant","pravakar","sunil","sibaram");
$lname = $l[mt_rand(0,50)];

function asidr($length) {
    $characters = '0123456789abcdefghi';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
function asid(){
 return $a=''.asidr(8).'-'.asidr(4).'-'.asidr(4).'-'.asidr(4).'-'.asidr(12).'';
}
$asid=asid();

function Rando($length) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
function fcm_r($a){
 $b=strlen($a);
 return $e=Rando($b);
}
function fcm(){
 return$a=''.fcm_r('dkRzkTOWTk6e9').'-'.fcm_r('B35s39qF').':'.fcm_r('APA91bGB').'-'.fcm_r('Y0VyLpjdef95').'-'.fcm_r('R4gQc9HQ2NpqIP9JSXn0hi_m2O5wfq2ctdT6xnmf_pPu4MmCANcSwCdkFFLh9U5toMYjDSMD69nzdAxOqZL0xx8zJG957CqASbATV4Wbf8jvtRXhPffF58').'';
}
$fcm=fcm();
$de=asidr(16);
$a1=mt_rand(63,99);
$a2=mt_rand(11111111,88888888);
$number="$a1$a2";
$p=mt_rand(111111,999999);
$dev=mt_rand(11,99);
$LoNg=mt_rand(1111,99999);
$ip = long2ip(rand());

if($refer){

$url="http://3.109.115.226:3000/login";
$data='{"ccode":"IN","deviceId":"'.$de.'","model":"M2101K7BI","email":"'.$fname.''.$lname.''.$p.'@gmail.com","gaid":"'.$asid.'","imei":"","ip":"fe80::c89c:43ff:fe63:cfd2","lat":0.0,"long":0.0,"no":"'.$number.'","name":"'.$fname.'","oem":"Redmi","os":"R","referral":"'.$refer.'","token":"'.$fcm.'"}';
$headers=['bitch: '.$number.'','Content-Type: application/json; charset=UTF-8'];
$output=httpCall($url,$data,$headers,"POST",0);
$status=json_decode($output,1)['status'];


	echo"<center><b><font color='green'>$output</center></b></font>";

echo"<meta http-equiv='refresh' content=2;url=https://telegram.dog/techearningguruji>";

}

?>